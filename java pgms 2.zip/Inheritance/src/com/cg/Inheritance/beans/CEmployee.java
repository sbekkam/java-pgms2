package com.cg.Inheritance.beans;

	public final  class CEmployee extends Employee {
		int hrs,variablepay;

		public CEmployee() {
			super();

		}

		public CEmployee(int employeeId, int basicSalary, String firstName, String lastName,int hrs) {
			super(employeeId, basicSalary, firstName, lastName);
			this.hrs=hrs;
		}

		public int getHrs() {
			return hrs;
		}

		public void setHrs(int hrs) {
			this.hrs = hrs;
		}

		public int getVariablepay() {
			return variablepay;
		}

		public void setVariablepay(int variablepay) {
			this.variablepay = variablepay;
		}
		public void signedContract() {
			System.out.println("Contract has been signed");
		}
		public void calculateSalary() {
			this.setVariablepay(500*getHrs());
		}

		@Override
		public String toString() {
			return super.toString()+"hrs=" + this.hrs + ", variablepay=" + this.variablepay ;
		}
		


	}



