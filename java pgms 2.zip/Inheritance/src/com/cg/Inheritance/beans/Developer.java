package com.cg.Inheritance.beans;

public class Developer extends PEmployee{
	int incentives,noOfPgms;

	public Developer() {
		super();

	}

	public Developer(int employeeId, int basicSalary, String firstName, String lastName,int noOfPgms) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfPgms=noOfPgms;
	}
	

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}

	public int getNoOfPgms() {
		return noOfPgms;
	}

	public void setNoOfPgms(int noOfPgms) {
		this.noOfPgms = noOfPgms;
	}

	public void developeAProgram() {
		System.out.println("program developed");
	}
	public void calculateSalary() {
		super.calculateSalary();
		this.setIncentives(1*noOfPgms/100);
		this.setTotalSalary(getIncentives()+this.getBasicSalary());
	}

	@Override
	public String toString() {
		return super.toString()+ "noOfPgms=" + this.noOfPgms + ", incentives=" + this.incentives;
	}

	

	

}






