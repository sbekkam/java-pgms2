package com.cg.Inheritance.main;


import com.cg.Inheritance.beans.CEmployee;
import com.cg.Inheritance.beans.Developer;
import com.cg.Inheritance.beans.Employee;
import com.cg.Inheritance.beans.PEmployee;
import com.cg.Inheritance.beans.SalesManager;

public  class MainClass {

	public static void main(String[] args) {
		Employee employee=new Employee(111, 1500, "Satish", "Prasad");
		employee.calculateSalary();
		System.out.println(employee.toString());

		employee =new PEmployee(111, 1500, "sushma", "bekkam");
		PEmployee pemp=( PEmployee) employee;
		employee.calculateSalary();
		System.out.println(employee);

		employee =new CEmployee(122, 145, "navya", "kudupudi", 100);
		CEmployee cemp=(CEmployee) employee;
		employee.calculateSalary();
		cemp.signedContract();
		System.out.println(employee);

		employee = new SalesManager(113, 1000, "abc", "def", 1000);
		SalesManager s =(SalesManager) employee;
		employee.calculateSalary();
		s.doAsales();
		System.out.println(employee);

		employee = new Developer(113, 1000, "shyam", "bachu", 1000);
		Developer d =(Developer) employee;
		employee.calculateSalary();
		d.developeAProgram();
		System.out.println(employee);


	}





}


