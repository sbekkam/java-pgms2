package com.cg.math.services;

import com.cg.math.exceptions.InValidNoRangeException;

public class MainClass {

	public static void main(String[] args) throws InValidNoRangeException {
		MathServices mathServices = new MathServicesImpl();
		mathServices.add(10, 20);
		}

}
