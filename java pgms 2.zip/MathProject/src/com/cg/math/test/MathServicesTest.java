
package com.cg.math.test;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.math.exceptions.InValidNoRangeException;
import com.cg.math.services.MathServices;
import com.cg.math.services.MathServicesImpl;


public class MathServicesTest {

		public static MathServices services;
		private int validNum1,validNum2,inValidNum1,inValidNum2,expectedAns;
		
		@BeforeClass
		public static void setUpTestEnv(){
			services =new MathServicesImpl();
		}
		
		@Before
		public void setUpMockData(){
			validNum1 =100;
			validNum2=20;
			inValidNum1=-30;
			inValidNum2=-40;
		}
		@Test(expected=InValidNoRangeException.class)
		public void testAddForFirstInvalidN0() throws InValidNoRangeException{
			services.add(inValidNum1, inValidNum2);
		}
		@Test(expected=InValidNoRangeException.class)
		public void testAddForSecondInvalidN0() throws InValidNoRangeException{
			services.add(validNum1, inValidNum2);
		}
		
		@Test
		public void testAddForValidNo() throws InValidNoRangeException {
			int actualAns=services.add(validNum1, validNum2);
			expectedAns=120;
			Assert.assertEquals(expectedAns, actualAns);
		}
		@Test(expected=InValidNoRangeException.class)
		public void testSubForFirstInvalidN0() throws InValidNoRangeException{
			services.sub(inValidNum1, inValidNum2);
		}
		@Test(expected=InValidNoRangeException.class)
		public void testSbForSecondInvalidN0() throws InValidNoRangeException{
			services.sub(validNum1, inValidNum2);
		}
		
		@Test
		public void testSubForValidNo() throws InValidNoRangeException {
			int actualAns=services.sub(validNum1, validNum2);
			expectedAns=80;
			Assert.assertEquals(expectedAns, actualAns);
		}
		@Test(expected=InValidNoRangeException.class)
		public void testDivForFirstInvalidN0() throws InValidNoRangeException{
			services.div(inValidNum1, inValidNum2);
		}
		@Test(expected=InValidNoRangeException.class)
		public void testDivForSecondInvalidN0() throws InValidNoRangeException{
			services.div(validNum1, inValidNum2);
		}
		
		@Test
		public void testDivForValidNo() throws InValidNoRangeException {
			int actualAns=services.div(validNum1, validNum2);
			expectedAns=5;
			Assert.assertEquals(expectedAns, actualAns);
		}
		
		
}
