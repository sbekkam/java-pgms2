package com.cg.project.collections;

public class Customer {
	private String firstName,lastname;
	private int customerId;
	public Customer(String firstName, String lastname, int customerId) {
		super();
		this.firstName = firstName;
		this.lastname = lastname;
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int compareTo(Customer customer){
		return this.firstName.compareTo(customer.firstName);
		
		
	}

}
