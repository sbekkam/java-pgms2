package com.cg.project.collections;

import java.util.List;
import java.util.ArrayList;

public class MainClass2 {

	public static void main(String[] args) {
		//MyGenricType<String> ref1 = new MyGenricType<String>("hello", "world");
		//MyGenricType<Integer>ref2 = new MyGenricType<Integer>(10, 20);
		//MyGenricType<customer>ref3=new MyGenricType<customer>(obj1, obj2)
		ArrayList<String> strList =new ArrayList<>();
		strList.add("sushu");
		strList.add("shyam");
		strList.add("pony");
		iterateOnList(strList);
	
	ArrayList<Integer> intList = new ArrayList<>();

		intList.add(10);
		intList.add(20);
		intList.add(30);
		iterateOnList(intList);
	}
		private  static void iterateOnList(List<? extends Comparable<?>> elements){
			 for (Comparable<?> comparable : elements) {
				System.out.println(comparable);
			}
		
		}	
}
