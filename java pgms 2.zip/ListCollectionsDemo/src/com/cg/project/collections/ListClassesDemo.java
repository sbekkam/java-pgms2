package com.cg.project.collections;

import java.util.ArrayList;
public class ListClassesDemo {
	public static void arrayListClassWork() {
		ArrayList<String> strList=new ArrayList<>();
		strList.add("sushma");
		strList.add("navya");
		strList.add("ram");
		strList.add("shyam");
		strList.add("karhik");
		strList.add("pony");
		strList.add("sam");
		
		//Iterator
		//Iterator<String>iterator=strList.length;
		ArrayList<Customer>customerList=new ArrayList<>();
		customerList.add(new Customer("sushma", "bekkam", 111));
		customerList.add(new Customer("navya", "lastname", 112));
		customerList.add(new Customer("ram", "bollineni", 113));
		customerList.add(new Customer("shyam", "bachu", 114));
		customerList.add(new Customer("karthik", "upendram", 115));
		Customer customerToBeSearch=new Customer("ram", "bollineni", 113);
		System.out.println(customerList.contains(customerToBeSearch));
		//Collection.sort(customerList);
		for (Customer customer : customerList) {
			System.out.println(customer);
			
		} 
	}

}
