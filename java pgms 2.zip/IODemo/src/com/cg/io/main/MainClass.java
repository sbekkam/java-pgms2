package com.cg.io.main;

import java.io.File;
import java.io.IOException;

import com.cg.io.beans.SerializationDemo;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException {
		//File file= new File("d:\\sushmaFile.txt");
		//File file1= new File("d:\\sushmaFile1.txt");
		File desfile=new File("d:\\sushmaFile.txt");
		try {
		
			SerializationDemo.doSerialization(desfile);
			//ByteStreamDemo.byteReadWriteWork(file,file1);
		//	ByteStreamDemo.byteReadWriteWork(file1);
			
			

			//if(!file.exists())
				//file.createNewFile();

		/*	System.out.println(file.length());
			System.out.println(file.canRead());
			System.out.println(file.canWrite());*/
				


		} catch (IOException e) {
			e.printStackTrace();
		}


	}

}
