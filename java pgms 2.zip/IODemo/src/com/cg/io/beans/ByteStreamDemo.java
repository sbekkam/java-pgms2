package com.cg.io.beans;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class ByteStreamDemo {
	public static void byteReadWriteWork(File fromfile,File tofile) throws IOException{
		FileInputStream src = new FileInputStream(fromfile);
		//FileOutputStream dest= new FileOutputStream(tofile);
		int a=0;
		while((a=src.read())!= -1){
			System.out.print((char)a);
			
			//2d way
		/*byte []dataBuffer = new byte[(int)fromfile.length()];
			src.read(dataBuffer);
			dest.write(dataBuffer);*/

			
		}
		
		
	}
	
	


}
