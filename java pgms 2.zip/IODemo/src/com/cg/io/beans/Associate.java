package com.cg.io.beans;

import java.io.Serializable;

public class Associate  implements Serializable{
	private String firstName,lastName;
	private int associateId,basicSalary;
    public 	Associate (){	}
	public Associate(String firstName, String lastName, int associateId, int basicSalary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.associateId = associateId;
		this.basicSalary = basicSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
    
    
	}
	


